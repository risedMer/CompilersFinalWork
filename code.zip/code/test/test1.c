void main(int n) {
	int x;
	x = 5;
	print x;
	print n;
//	for(x=0;x<5;x++) {
//		print x;
//	}
//	print x;
//	x = 1.0;
//	print x;
	return 0;
} 
