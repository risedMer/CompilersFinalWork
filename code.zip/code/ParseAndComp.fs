module ParseAndComp

let fromString = Parse.fromString

let fromFile = Parse.fromFile

let compileToFile = XMComp.compileToFile